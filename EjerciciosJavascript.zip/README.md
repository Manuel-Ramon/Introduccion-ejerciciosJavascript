#			--Usabilidad y Accesibilidad--

##			-Ejercicios de Javascript-

### Grupo 6

*Ejercicios número 1,2: Javascript.pdf
*Ejercicio número 3: primero(limpio).html
*Ejercicio número 4: segundo(limpio).html
*Ejercicio número 5: tercero.html
